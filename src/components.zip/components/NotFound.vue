<template>
  <div style="text-align:center;">
      <h3>Page Not Found</h3>
  </div>
</template>

<script>
export default {
    name: "NotFound",
    components: {
    },
}
</script>

<style>
</style>